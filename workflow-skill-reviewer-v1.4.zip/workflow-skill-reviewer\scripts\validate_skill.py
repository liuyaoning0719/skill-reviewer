#!/usr/bin/env python3
"""
Validate a workflow skill directory against structural requirements.

Usage:
    python validate_skill.py <skill-directory> [--parent-dir <parent>]

Exit codes:
    0 - All checks passed
    1 - One or more checks failed
"""

import sys
import os
import re
import yaml
from pathlib import Path


class Colors:
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    RESET = "\033[0m"


def print_pass(msg):
    print(f"  {Colors.GREEN}PASS{Colors.RESET} {msg}")


def print_warn(msg):
    print(f"  {Colors.YELLOW}WARN{Colors.RESET} {msg}")


def print_fail(msg):
    print(f"  {Colors.RED}FAIL{Colors.RESET} {msg}")


def check_frontmatter(skill_dir: Path) -> dict:
    """Parse and validate SKILL.md frontmatter."""
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        print_fail("SKILL.md does not exist")
        return None

    content = skill_md.read_text(encoding="utf-8")

    # Extract frontmatter
    if not content.startswith("---"):
        print_fail("SKILL.md does not start with YAML frontmatter")
        return None

    parts = content.split("---", 2)
    if len(parts) < 3:
        print_fail("SKILL.md frontmatter is malformed")
        return None

    try:
        frontmatter = yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print_fail(f"Frontmatter YAML parse error: {e}")
        return None

    if not isinstance(frontmatter, dict):
        print_fail("Frontmatter is not a YAML mapping")
        return None

    return frontmatter


def validate_skill(skill_dir: Path, parent_dir: Path = None) -> bool:
    """Run all validation checks. Returns True if all critical checks pass."""
    all_pass = True
    skill_name = skill_dir.name

    print(f"\nValidating skill: {skill_name}")
    print("=" * 50)

    # Check 1: SKILL.md exists
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        print_fail("SKILL.md is required but missing")
        return False
    print_pass("SKILL.md exists")

    # Check 2: Frontmatter
    fm = check_frontmatter(skill_dir)
    if fm is None:
        return False

    # Check 3: Name field
    name = fm.get("name")
    if not name:
        print_fail("Frontmatter missing required field: name")
        all_pass = False
    elif name != skill_name:
        print_fail(f"name '{name}' does not match directory name '{skill_name}'")
        all_pass = False
    elif not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", name):
        print_fail(f"name '{name}' must be lowercase letters, digits, hyphens only")
        all_pass = False
    elif len(name) > 64:
        print_fail(f"name '{name}' exceeds 64 characters")
        all_pass = False
    else:
        print_pass(f"name '{name}' is valid")

    # Check 4: Description field
    description = fm.get("description")
    if not description:
        print_fail("Frontmatter missing required field: description")
        all_pass = False
    elif len(description) > 1024:
        print_fail(f"description exceeds 1024 chars ({len(description)})")
        all_pass = False
    else:
        print_pass(f"description is present ({len(description)} chars)")

    # Check 5: No extra frontmatter fields
    allowed_fields = {"name", "description"}
    if "type" in fm:
        allowed_fields.add("type")
    if "allowed-tools" in fm:
        allowed_fields.add("allowed-tools")
    if "tools" in fm:
        allowed_fields.add("tools")
    extra = set(fm.keys()) - allowed_fields
    if extra:
        print_warn(f"Extra frontmatter fields detected: {extra}")
    else:
        print_pass("No unexpected frontmatter fields")

    # Check 6: Line count
    content = skill_md.read_text(encoding="utf-8")
    lines = content.splitlines()
    line_count = len(lines)
    if line_count > 500:
        print_fail(f"SKILL.md exceeds 500 lines ({line_count})")
        all_pass = False
    elif line_count > 300:
        print_warn(f"SKILL.md is {line_count} lines (ideal: < 300)")
    else:
        print_pass(f"SKILL.md is {line_count} lines")

    # Check 7: Forbidden files
    forbidden = {"README.md", "CHANGELOG.md", "INSTALLATION_GUIDE.md",
                 "QUICK_REFERENCE.md", "readme.md", "changelog.md"}
    found_forbidden = []
    for f in skill_dir.iterdir():
        if f.name in forbidden:
            found_forbidden.append(f.name)
    if found_forbidden:
        print_fail(f"Forbidden documentation files found: {found_forbidden}")
        all_pass = False
    else:
        print_pass("No forbidden documentation files")

    # Check 8: Directory depth (strictly one level deep)
    # A skill is a single unit; all subdirectories must be flat (no nesting).
    # If you need atoms/molecules/compounds layers, make them separate skills
    # in a parent suite directory, not nested subdirs inside one skill.
    nested_found = False
    for subdir in skill_dir.iterdir():
        if not subdir.is_dir():
            continue
        for child in subdir.iterdir():
            if child.is_dir():
                print_fail(f"Nested directory detected (max 1 level): {child}")
                all_pass = False
                nested_found = True
                break
        if nested_found:
            break
    if not nested_found:
        print_pass("Directory structure is flat (one level deep)")

    # Check 9: Reference chains (A -> B -> C)
    ref_dir = skill_dir / "references"
    if ref_dir.exists():
        ref_files = {f.name for f in ref_dir.iterdir() if f.is_file()}
        chained = False
        for ref_file in ref_dir.iterdir():
            if not ref_file.is_file():
                continue
            text = ref_file.read_text(encoding="utf-8")
            links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', text)
            for _, link_path in links:
                clean = link_path.split("#")[0].split("?")[0]
                if clean and os.path.basename(clean) in ref_files:
                    if os.path.basename(clean) != ref_file.name:
                        print_warn(f"Potential reference chain: {ref_file.name} -> {clean}")
                        chained = True
        if not chained:
            print_pass("No reference chains detected")
    else:
        print_pass("No references/ directory (optional)")

    # Check 10: Broken file references in SKILL.md
    all_refs = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', content)
    broken = []
    for _, ref_path in all_refs:
        clean = ref_path.split("#")[0].split("?")[0]
        if not clean:
            continue
        if clean.startswith(("http://", "https://")):
            continue
        target = skill_dir / clean
        if not target.exists():
            broken.append(clean)
    if broken:
        print_fail(f"Broken file references in SKILL.md: {broken}")
        all_pass = False
    else:
        print_pass("All file references in SKILL.md resolve")

    # Check 11: Hardcoded absolute paths
    abs_path_pattern = re.compile(r'["\']?/(?:home|Users|usr|opt|var|tmp)/[^"\'\s]+')
    matches = abs_path_pattern.findall(content)
    if matches:
        print_warn(f"Potential hardcoded absolute paths: {matches[:3]}")
    else:
        print_pass("No hardcoded absolute paths detected")

    # Check 12: Has When to Use / When NOT to Use
    has_when_to_use = re.search(r'##\s*When to Use', content, re.IGNORECASE) is not None
    has_when_not = re.search(r'##\s*When NOT to Use', content, re.IGNORECASE) is not None
    if has_when_to_use and has_when_not:
        print_pass("Has both 'When to Use' and 'When NOT to Use' sections")
    else:
        missing = []
        if not has_when_to_use:
            missing.append("'When to Use'")
        if not has_when_not:
            missing.append("'When NOT to Use'")
        print_fail(f"Missing sections: {', '.join(missing)}")
        all_pass = False

    # Check 13: Flow skill structure (if type: flow)
    skill_type = fm.get("type", "standard")
    if skill_type == "flow":
        has_begin = re.search(r'BEGIN', content) is not None
        has_end = re.search(r'END', content) is not None
        if has_begin and has_end:
            print_pass("Flow skill has BEGIN and END markers")
        else:
            missing_markers = []
            if not has_begin:
                missing_markers.append("BEGIN")
            if not has_end:
                missing_markers.append("END")
            print_fail(f"Flow skill missing markers: {', '.join(missing_markers)}")
            all_pass = False
    else:
        print_pass("Not a flow skill (no BEGIN/END required)")

    # ============================================================
    # NEW CHECKS (v1.3)
    # ============================================================

    # Check 14: metadata.requires existence (C1 cross-skill contract)
    # Support both flat 'requires:' and nested 'metadata.copaw.requires:'
    requires = []
    if "requires" in fm:
        requires = fm["requires"]
    elif isinstance(fm.get("metadata"), dict):
        meta = fm["metadata"]
        if "requires" in meta:
            requires = meta["requires"]
        else:
            # Deep search one more level (e.g. metadata.copaw.requires)
            for subval in meta.values():
                if isinstance(subval, dict) and "requires" in subval:
                    requires = subval["requires"]
                    break
    if not isinstance(requires, list):
        requires = [requires] if requires else []

    if requires and parent_dir:
        missing_reqs = []
        for req in requires:
            req_path = parent_dir / req
            if not req_path.exists():
                missing_reqs.append(req)
        if missing_reqs:
            print_fail(f"Requires ghost skill(s) not found in parent dir: {missing_reqs}")
            all_pass = False
        else:
            print_pass(f"All required skills exist: {requires}")
    elif requires and not parent_dir:
        print_warn(f"Cannot verify requires without --parent-dir: {requires}")
    else:
        print_pass("No cross-skill requires declared")

    # Check 15: Script duplication across sibling skills (AP-22)
    if parent_dir:
        script_counts = {}
        for sibling in parent_dir.iterdir():
            if not sibling.is_dir():
                continue
            sibling_scripts = sibling / "scripts"
            if not sibling_scripts.exists():
                continue
            for script_file in sibling_scripts.rglob("*.py"):
                rel_name = script_file.name
                if rel_name not in script_counts:
                    script_counts[rel_name] = []
                script_counts[rel_name].append(sibling.name)

        duplicates = {k: v for k, v in script_counts.items() if len(v) > 1}
        if duplicates:
            dup_msg = ", ".join([f"{f} in {dirs}" for f, dirs in duplicates.items()])
            print_warn(f"Script duplication across skills: {dup_msg}")
        else:
            print_pass("No script duplication across sibling skills")
    else:
        print_pass("Script duplication check skipped (no parent-dir)")

    # Check 16: Architecture semantic drift (AP-23)
    # If SKILL.md describes atoms/molecules/compounds layers, check if dirs match
    layer_keywords = ["atoms", "molecules", "compounds", "原子层", "分子层", "化合物层"]
    describes_layers = any(kw in content.lower() for kw in layer_keywords)
    if describes_layers:
        found_layers = []
        for subdir in skill_dir.iterdir():
            if not subdir.is_dir():
                continue
            if subdir.name.lower() in ("atoms", "molecules", "compounds"):
                found_layers.append(subdir.name)
            # Also check inside scripts/ and references/
            for child in subdir.iterdir():
                if child.is_dir() and child.name.lower() in ("atoms", "molecules", "compounds"):
                    found_layers.append(f"{subdir.name}/{child.name}")

        if found_layers:
            print_pass(f"Architecture layers found: {found_layers}")
        else:
            print_warn("SKILL.md describes atoms/molecules/compounds layers but no matching directories found")
    else:
        print_pass("No architecture layer keywords detected")

    # ============================================================
    # NEW CHECKS (v1.4)
    # ============================================================

    # Check 17: Flow Skill diagram validation
    skill_type = fm.get("type", "standard")
    if skill_type == "flow":
        has_mermaid = re.search(r'```mermaid', content) is not None
        has_d2 = re.search(r'```d2', content) is not None
        has_begin = re.search(r'BEGIN', content) is not None
        has_end = re.search(r'END', content) is not None
        if not (has_mermaid or has_d2):
            print_fail("Flow skill missing Mermaid or D2 diagram")
            all_pass = False
        else:
            print_pass("Flow skill has Mermaid or D2 diagram")
        if not has_begin:
            print_fail("Flow skill missing BEGIN node")
            all_pass = False
        else:
            print_pass("Flow skill has BEGIN node")
        if not has_end:
            print_fail("Flow skill missing END node")
            all_pass = False
        else:
            print_pass("Flow skill has END node")
        has_choice = re.search(r'<choice>', content) is not None
        if has_choice:
            print_pass("Flow skill has choice markers for branching")
        else:
            print_warn("Flow skill has no branching choice markers (optional but recommended)")
    else:
        print_pass("Not a flow skill (no diagram check required)")

    # Check 18: ASI-friendly description (Anti-Pattern 25)
    # Description should NOT contain implementation details, script names, or phase internals
    # because Kimi only loads name+description at startup; implementation belongs in body
    desc_impl_leaks = []
    impl_keywords = ["scripts/", "references/", "step 1", "phase 1", "entry criteria",
                     "exit criteria", "json output", "yaml frontmatter", "loop guard",
                     "max iteration", "tool call", "subagent"]
    desc_lower = description.lower() if description else ""
    for kw in impl_keywords:
        if kw in desc_lower:
            desc_impl_leaks.append(kw)
    if desc_impl_leaks:
        print_warn(f"Description may leak implementation details (ASI anti-pattern): {desc_impl_leaks}")
    else:
        print_pass("Description is ASI-friendly (no implementation leaks)")

    # Check 19: Resilience mechanisms (Anti-Pattern 26)
    resilience_keywords = ["timeout", "retry", "fallback", "降级", "回退",
                           "graceful degradation", "circuit breaker", "重试", "超时"]
    has_resilience = any(kw in content.lower() for kw in resilience_keywords)
    sensitive_keywords = ["confirm", "确认", "approval", "审批", "人工介入", "human-in-the-loop",
                          "sensitive", "destructive", "delete", "remove", "drop"]
    has_sensitive_guard = any(kw in content.lower() for kw in sensitive_keywords)
    if has_resilience:
        print_pass("Resilience mechanisms detected (timeout/retry/fallback)")
    else:
        print_warn("No resilience mechanisms detected (timeout/retry/fallback)")
    if has_sensitive_guard:
        print_pass("Sensitive operation guards detected (confirmation/approval)")
    else:
        print_warn("No sensitive operation guards detected (confirmation/approval)")

    # Check 20: Credential isolation (Anti-Pattern 27)
    # Look for hardcoded API keys, passwords, tokens, secrets
    cred_patterns = [
        r'(api[_-]?key\s*[=:]\s*["\']?[a-zA-Z0-9]{16,}["\']?)',
        r'(password\s*[=:]\s*["\'][^"\']+["\'])',
        r'(token\s*[=:]\s*["\']?[a-zA-Z0-9_-]{20,}["\']?)',
        r'(secret\s*[=:]\s*["\']?[a-zA-Z0-9]{16,}["\']?)',
        r'(sk-[a-zA-Z0-9]{20,})',  # OpenAI-style key
        r'(AK[0-9A-Z]{16,})',       # AWS-style key
    ]
    cred_leaks = []
    for pattern in cred_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        cred_leaks.extend(matches[:3])  # limit output
    # Also check for placeholder patterns which are good
    placeholder_patterns = [r'fill_in_valid_value', r'YOUR_', r'{{.*}}', r'\$\{.*\}', r'<your-']
    has_placeholders = any(re.search(p, content, re.IGNORECASE) for p in placeholder_patterns)
    if cred_leaks:
        print_fail(f"Potential hardcoded credentials detected: {cred_leaks}")
        all_pass = False
    else:
        print_pass("No hardcoded credentials detected")
    if has_placeholders:
        print_pass("Credential placeholders detected (good practice)")
    else:
        print_warn("No credential placeholders found (recommend using {{variable}} or YOUR_XXX)")

    # Summary
    print("=" * 50)
    if all_pass:
        print(f"{Colors.GREEN}All critical checks passed.{Colors.RESET}")
    else:
        print(f"{Colors.RED}One or more critical checks failed.{Colors.RESET}")

    return all_pass


def validate_suite(suite_dir: Path) -> bool:
    """Validate a skill suite: multiple skills with hierarchical relationships."""
    suite_all_pass = True
    skills = [d for d in suite_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists()]

    print(f"\n{Colors.GREEN}=== SUITE MODE ==={Colors.RESET}")
    print(f"Scanning suite: {suite_dir.name}")
    print(f"Found {len(skills)} skill(s): {[s.name for s in skills]}\n")

    # Phase 1: Validate each skill individually
    individual_pass = True
    for skill in skills:
        passed = validate_skill(skill, suite_dir)
        if not passed:
            individual_pass = False
        print()

    # Phase 2: Cross-skill relationship analysis
    print(f"{Colors.GREEN}=== Suite Relationship Analysis ==={Colors.RESET}")

    # Build requires graph
    req_graph = {}  # skill_name -> [required_skills]
    for skill in skills:
        fm = check_frontmatter(skill)
        if not fm:
            continue
        requires = []
        if "requires" in fm:
            requires = fm["requires"]
        elif isinstance(fm.get("metadata"), dict):
            meta = fm["metadata"]
            if "requires" in meta:
                requires = meta["requires"]
            else:
                for subval in meta.values():
                    if isinstance(subval, dict) and "requires" in subval:
                        requires = subval["requires"]
                        break
        if not isinstance(requires, list):
            requires = [requires] if requires else []
        req_graph[skill.name] = requires

    # Check for external dependencies (requires outside suite)
    suite_names = {s.name for s in skills}
    external_deps = {}
    for skill_name, reqs in req_graph.items():
        for req in reqs:
            if req not in suite_names:
                if skill_name not in external_deps:
                    external_deps[skill_name] = []
                external_deps[skill_name].append(req)

    if external_deps:
        print_warn(f"External dependencies (outside suite): {external_deps}")
    else:
        print_pass("All dependencies resolved within suite")

    # Check for requires ghosts within suite
    ghosts = {}
    for skill_name, reqs in req_graph.items():
        for req in reqs:
            if req not in suite_names:
                if skill_name not in ghosts:
                    ghosts[skill_name] = []
                ghosts[skill_name].append(req)

    if ghosts:
        print_fail(f"Requires ghost within suite: {ghosts}")
        suite_all_pass = False
    else:
        print_pass("No ghost dependencies within suite")

    # Check layer semantics (use directory name + self-description heuristics)
    layer_map = {}
    for skill in skills:
        name_lower = skill.name.lower()
        # Priority 1: directory name hints
        if any(k in name_lower for k in ["atom", "原子"]):
            layer_map[skill.name] = "atom"
        elif any(k in name_lower for k in ["molecule", "分子", "molecules"]):
            layer_map[skill.name] = "molecule"
        elif any(k in name_lower for k in ["compound", "化合物", "workflow", "workflow"]):
            layer_map[skill.name] = "compound"
        else:
            # Priority 2: first 500 chars of SKILL.md self-description
            content = (skill / "SKILL.md").read_text(encoding="utf-8").lower()[:500]
            if any(kw in content for kw in ["atom", "原子层", "原子"]):
                layer_map[skill.name] = "atom"
            elif any(kw in content for kw in ["molecule", "分子层", "分子"]):
                layer_map[skill.name] = "molecule"
            elif any(kw in content for kw in ["compound", "化合物层", "化合物", "orchestrat", "编排"]):
                layer_map[skill.name] = "compound"
            else:
                layer_map[skill.name] = "unknown"

    print(f"Layer mapping: {layer_map}")

    # Check call direction: compound should call molecule, molecule should call atom
    direction_issues = []
    for caller, reqs in req_graph.items():
        caller_layer = layer_map.get(caller, "unknown")
        for req in reqs:
            if req in layer_map:
                req_layer = layer_map[req]
                valid = False
                if caller_layer == "compound" and req_layer in ("molecule", "atom"):
                    valid = True
                elif caller_layer == "molecule" and req_layer == "atom":
                    valid = True
                elif caller_layer == req_layer:
                    valid = True  # Same-layer calls allowed
                elif caller_layer == "unknown" or req_layer == "unknown":
                    valid = True
                if not valid:
                    direction_issues.append(
                        f"{caller}({caller_layer}) -> {req}({req_layer})"
                    )

    if direction_issues:
        print_warn(f"Layer direction issues: {direction_issues}")
    else:
        print_pass("All cross-skill calls follow valid layer directions")

    # Check for circular dependencies
    def has_cycle(start, visited, stack):
        visited.add(start)
        stack.add(start)
        for req in req_graph.get(start, []):
            if req not in visited:
                if has_cycle(req, visited, stack):
                    return True
            elif req in stack:
                return True
        stack.remove(start)
        return False

    cycles = []
    for skill_name in req_graph:
        if has_cycle(skill_name, set(), set()):
            cycles.append(skill_name)

    if cycles:
        print_fail(f"Circular dependency detected involving: {cycles}")
        suite_all_pass = False
    else:
        print_pass("No circular dependencies")

    # Summary
    print("=" * 50)
    if suite_all_pass and individual_pass:
        print(f"{Colors.GREEN}Suite validation passed.{Colors.RESET}")
    else:
        print(f"{Colors.RED}Suite validation failed.{Colors.RESET}")

    return suite_all_pass and individual_pass


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <skill-directory> [--parent-dir <parent>]")
        print(f"       {sys.argv[0]} --suite <suite-directory>")
        sys.exit(1)

    if sys.argv[1] == "--suite":
        if len(sys.argv) < 3:
            print("Usage: --suite <suite-directory>")
            sys.exit(1)
        suite_dir = Path(sys.argv[2]).resolve()
        if not suite_dir.exists() or not suite_dir.is_dir():
            print(f"Not a directory: {suite_dir}")
            sys.exit(1)
        passed = validate_suite(suite_dir)
        sys.exit(0 if passed else 1)

    skill_dir = Path(sys.argv[1]).resolve()
    if not skill_dir.exists():
        print(f"Directory not found: {skill_dir}")
        sys.exit(1)

    if not skill_dir.is_dir():
        print(f"Not a directory: {skill_dir}")
        sys.exit(1)

    parent_dir = None
    if "--parent-dir" in sys.argv:
        idx = sys.argv.index("--parent-dir")
        if idx + 1 < len(sys.argv):
            parent_dir = Path(sys.argv[idx + 1]).resolve()

    passed = validate_skill(skill_dir, parent_dir)
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
