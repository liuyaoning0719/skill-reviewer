# Workflow Patterns

Five structural patterns for reliable multi-step workflow skills.

Use the decision tree below to select the right pattern:

```
How many distinct paths does the skill have?
│
+-- One path, always the same
│   +-- Does it perform destructive actions?
│       +-- YES -> Safety Gate Pattern
│       +-- NO  -> Linear Progression Pattern
│
+-- Multiple independent paths from shared setup
│   +-- Routing Pattern
│
+-- Multiple dependent steps in sequence
    +-- Do steps have complex dependencies?
        +-- YES -> Task-Driven Pattern
        +-- NO  -> Sequential Pipeline Pattern
```

---

## Pattern 1: Linear Progression

**Use when**: Single path, same every time, no destructive actions.
**Key feature**: Numbered phases with entry/exit criteria.

### Skeleton

```markdown
---
name: example-linear
description: ...
---

## Phase 1: [Name]
**Entry criteria**: [What must be true]
**Actions**:
1. [Specific action]
2. [Specific action]
**Exit criteria**: [How to know it's done]

## Phase 2: [Name]
**Entry criteria**: [What must be true]
**Actions**:
1. [Specific action]
2. [Specific action]
**Exit criteria**: [How to know it's done]

## Phase N: Verification
**Entry criteria**: [What must be true]
**Actions**:
1. [Check output quality]
2. [Check no placeholders remain]
**Exit criteria**: [All checks pass]
```

### Example: Newsletter Formatter

```markdown
## Phase 1: Cleanup
**Entry**: Raw text provided.
**Actions**:
1. Remove excessive line breaks.
2. Fix spacing issues.
**Exit**: Text is a single clean paragraph stream.

## Phase 2: Structure
**Entry**: Clean text ready.
**Actions**:
1. Add Catchy Title.
2. Add Introduction.
3. Add Key Updates (bullets).
4. Add Quote of the Week.
5. Add Call to Action.
**Exit**: All required sections exist.

## Phase 3: Format
**Entry**: Structured content ready.
**Actions**:
1. Apply Markdown headers (#, ##).
2. Apply bolding where appropriate.
**Exit**: Properly formatted Markdown output.
```

---

## Pattern 2: Safety Gate

**Use when**: Destructive or irreversible actions (deletions, deployments, migrations).
**Key feature**: Two confirmation gates before execution.

### Skeleton

```markdown
---
name: example-safety
description: ...
---

## Gate 1: Pre-Check
**Entry criteria**: [Request received]
**Actions**:
1. List all files that will be modified/deleted.
2. Show a summary of the intended changes.
**Exit criteria**: User confirms the scope is correct.

## Gate 2: Final Confirmation
**Entry criteria**: Gate 1 passed.
**Actions**:
1. Display exact commands or changes that will execute.
2. Ask for explicit final confirmation (yes/no).
**Exit criteria**: User provides explicit "yes".

## Phase 3: Execution
**Entry criteria**: Both gates passed.
**Actions**:
1. Execute the approved changes.
2. Log results.
**Exit criteria**: Changes complete with no errors.

## Phase 4: Verification
**Entry criteria**: Execution complete.
**Actions**:
1. Verify changes match the approved scope.
2. Check system health.
**Exit criteria**: Verification passes.
```

### Example: Database Migration

```markdown
## Gate 1: Scope Confirmation
**Actions**:
1. Read migration file.
2. List tables/columns affected.
3. Show rollback script path.
**Exit**: User confirms scope.

## Gate 2: Backup Check
**Actions**:
1. Verify database backup exists and is recent (< 24h).
2. Display migration command: `alembic upgrade head`.
**Exit**: User confirms backup exists and approves command.

## Phase 3: Execute
**Actions**:
1. Run migration.
2. Capture output.
**Exit**: Migration completes successfully.

## Phase 4: Verify
**Actions**:
1. Check schema matches expected.
2. Run smoke tests.
**Exit**: Schema correct, tests pass.
```

---

## Pattern 3: Routing

**Use when**: Multiple independent tasks from a shared intake.
**Key feature**: Routing table maps intent to workflow files.

### Skeleton

```markdown
---
name: example-routing
description: ...
---

## Routing Table

| Intent | Trigger Keywords | Workflow File | Notes |
|--------|-----------------|---------------|-------|
| [Intent A] | [keyword1, keyword2] | `workflows/a.md` | [When to choose] |
| [Intent B] | [keyword3, keyword4] | `workflows/b.md` | [When to choose] |
| [Intent C] | [keyword5, keyword6] | `workflows/c.md` | [When to choose] |

## Fallback Rule
If no intent matches with >70% confidence, ask the user for clarification.
Do not guess.

## Shared Setup (All Routes)
**Actions**:
1. [Common initialization step]
2. [Common data loading step]
```

### Example: DevOps Toolkit

```markdown
## Routing Table

| Intent | Trigger Keywords | Workflow | Notes |
|--------|-----------------|----------|-------|
| Deploy | "deploy", "ship", "release" | `workflows/deploy.md` | Use for production deployments |
| Rollback | "rollback", "revert", "undo deploy" | `workflows/rollback.md` | Use when a deployment breaks |
| Status | "status", "health", "check" | `workflows/status.md` | Use for non-destructive checks |
| Scale | "scale", "resize", "capacity" | `workflows/scale.md` | Use for horizontal/vertical scaling |

## Shared Setup
**Actions**:
1. Load kubeconfig from `~/.kube/config`.
2. Verify cluster connectivity.
```

---

## Pattern 4: Sequential Pipeline

**Use when**: Dependent steps, each feeding the next. May need to resume from partial progress.
**Key feature**: Auto-detection can resume from wherever the pipeline left off.

### Skeleton

```markdown
---
name: example-pipeline
description: ...
---

## Pipeline Overview
Step 1 -> Step 2 -> Step 3 -> Step 4

## Resume Detection
On invocation, check which steps are already complete:
- If `output/step1.json` exists and valid, resume from Step 2.
- If `output/step2.json` exists and valid, resume from Step 3.
- Otherwise, start from Step 1.

## Step 1: [Name]
**Input**: [Initial input]
**Actions**: [What to do]
**Output**: `output/step1.json`
**Validation**: [How to verify output is correct]

## Step 2: [Name]
**Input**: `output/step1.json`
**Actions**: [What to do]
**Output**: `output/step2.json`
**Validation**: [How to verify output is correct]

## Step N: [Name]
**Input**: `output/step{N-1}.json`
**Actions**: [What to do]
**Output**: [Final output]
**Validation**: [Final verification]
```

### Example: Data Pipeline

```markdown
## Pipeline Overview
Extract -> Clean -> Transform -> Load

## Resume Detection
- If `data/raw.json` exists, skip Extract.
- If `data/clean.json` exists, skip Clean.
- If `data/transformed.json` exists, skip Transform.

## Step 1: Extract
**Input**: Source database connection.
**Actions**:
1. Run `scripts/extract.py --source db`.
**Output**: `data/raw.json`
**Validation**: File exists and > 0 bytes.

## Step 2: Clean
**Input**: `data/raw.json`
**Actions**:
1. Run `scripts/clean.py --input data/raw.json`.
**Output**: `data/clean.json`
**Validation**: No nulls in required fields.

## Step 3: Transform
**Input**: `data/clean.json`
**Actions**:
1. Run `scripts/transform.py --input data/clean.json`.
**Output**: `data/transformed.json`
**Validation**: Schema matches target.

## Step 4: Load
**Input**: `data/transformed.json`
**Actions**:
1. Run `scripts/load.py --input data/transformed.json --target warehouse`.
**Output**: Loaded rows count.
**Validation**: Row count matches input.
```

---

## Pattern 5: Task-Driven

**Use when**: Complex dependencies between steps. Partial failure tolerance needed.
**Key feature**: Uses task tracking with explicit dependencies.

### Skeleton

```markdown
---
name: example-task-driven
description: ...
---

## Task Registry

| Task ID | Description | Dependencies | Status | Output |
|---------|-------------|--------------|--------|--------|
| T1 | [Description] | None | Pending | [Output path] |
| T2 | [Description] | T1 | Pending | [Output path] |
| T3 | [Description] | T1 | Pending | [Output path] |
| T4 | [Description] | T2, T3 | Pending | [Output path] |

## Execution Rules
1. Only start tasks whose dependencies are all "Done".
2. If a task fails, mark it "Failed" and continue with independent tasks.
3. Report all failures at the end; do not silently skip.

## Task T1: [Name]
**Actions**: [What to do]
**On success**: Mark Done, write output to [path].
**On failure**: Mark Failed, log error, continue with T2/T3 if possible.

## Task T2: [Name]
**Dependencies**: T1 Done.
**Actions**: [What to do]
**On success**: Mark Done.
**On failure**: Mark Failed.

## Finalization
**Entry**: All tasks complete (Done or Failed).
**Actions**:
1. Report summary of completed tasks.
2. Report summary of failed tasks with error logs.
3. If any critical task failed, do not proceed to downstream actions.
```

### Example: Multi-Module Refactor

```markdown
## Task Registry

| ID | Description | Dependencies | Status |
|----|-------------|--------------|--------|
| T1 | Update shared utils | None | Pending |
| T2 | Refactor auth module | T1 | Pending |
| T3 | Refactor billing module | T1 | Pending |
| T4 | Update API routes | T2, T3 | Pending |
| T5 | Run integration tests | T4 | Pending |

## Execution
- Start T1 immediately.
- When T1 is Done, start T2 and T3 in parallel.
- When both T2 and T3 are Done, start T4.
- When T4 is Done, start T5.

## Failure Handling
- If T1 fails: Halt. Nothing can proceed.
- If T2 fails but T3 succeeds: Complete T3, skip T4/T5, report auth refactor blocked.
- If T3 fails but T2 succeeds: Complete T2, skip T4/T5, report billing refactor blocked.
```

---

## Pattern Comparison

| Pattern | Paths | Destructive? | Resumable? | Parallel? | Best For |
|---------|-------|--------------|------------|-----------|----------|
| Linear | 1 | No | No | No | Simple, repeatable procedures |
| Safety Gate | 1 | Yes | No | No | Migrations, deletions, releases |
| Routing | N | Maybe | No | No | Multi-tool CLI, multi-domain skills |
| Sequential Pipeline | 1 | Maybe | Yes | No | ETL, builds, document generation |
| Task-Driven | N | Maybe | Yes | Yes | Complex refactors, distributed work |
