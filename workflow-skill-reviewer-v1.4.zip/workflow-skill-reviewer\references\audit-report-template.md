# Audit Report Template

Use this template for the final Phase 6 output.

---

## JSON Intermediate Summary

```json
{
  "audit_meta": {
    "skill_name": "ai-web-search",
    "skill_path": ".agents/skills/ai-web-search/",
    "audited_at": "2026-05-04T12:00:00Z",
    "auditor": "workflow-skill-reviewer"
  },
  "scores": {
    "trigger_accuracy": 92,
    "structural_fidelity": 88,
    "instruction_actionability": 85,
    "context_efficiency": 95,
    "drift_resistance": 75,
    "tool_minimality": 78,
    "scope_coherence": 95,
    "overall": 87
  },
  "issue_summary": {
    "critical": 1,
    "major": 2,
    "moderate": 1,
    "minor": 0,
    "total": 4
  },
  "issues": [
    {
      "id": "AP-12",
      "dimension": "tool_minimality",
      "severity": "critical",
      "location": "SKILL.md:12",
      "message": "Missing allowed-tools declaration in frontmatter",
      "fix": "Add allowed-tools: [SearchWeb, FetchURL, ReadFile, WriteFile, Shell, AskUserQuestion]"
    },
    {
      "id": "AP-7",
      "dimension": "drift_resistance",
      "severity": "major",
      "location": "SKILL.md:78",
      "message": "Infinite loop risk: content refinement cycle has no maximum iteration count",
      "fix": "Add loop guard: maximum 2 refinement cycles, then proceed with partial findings"
    }
  ],
  "verdict": "good",
  "next_action": "Fix AP-12 before deployment. Address AP-7 for production use."
}
```

---

## Markdown Final Report

```markdown
# Skill Audit Report: {skill-name}

**Audited**: YYYY-MM-DD
**Path**: {skill-path}
**Overall Score**: {score}/100 ({verdict})

---

## Executive Summary

- Skill type: {Flow / Standard}
- Detected pattern: {Linear / Pipeline / Routing / Safety Gate / Task-Driven / None}
- Total issues: {N} (Critical: {c}, Major: {m}, Moderate: {mod}, Minor: {min})
- Verdict: {Excellent / Good / Acceptable / Needs Work / Reject}

---

## Dimension Scores

| Dimension | Score | Weight | Weighted | Status |
|-----------|-------|--------|----------|--------|
| Trigger Accuracy | {s} | 20% | {w} | {🟢/🟡/🔴} |
| Structural Fidelity | {s} | 20% | {w} | {🟢/🟡/🔴} |
| Instruction Actionability | {s} | 20% | {w} | {🟢/🟡/🔴} |
| Context Efficiency | {s} | 15% | {w} | {🟢/🟡/🔴} |
| Drift Resistance | {s} | 10% | {w} | {🟢/🟡/🔴} |
| Tool Minimality | {s} | 10% | {w} | {🟢/🟡/🔴} |
| Scope Coherence | {s} | 5% | {w} | {🟢/🟡/🔴} |
| **Overall** | | | **{total}** | |

---

## Critical Issues (Fix Before Deploy)

### {ID}: {Title}
- **Location**: {file}:{line}
- **Severity**: 🔴 Critical
- **Current**:
  ```
  {bad example}
  ```
- **Recommended**:
  ```
  {good example}
  ```
- **Why**: {explanation}

---

## Major Issues (Fix Before Wide Adoption)

### {ID}: {Title}
- **Location**: {file}:{line}
- **Severity**: 🟠 Major
- **Current**: ...
- **Recommended**: ...

---

## Moderate Issues (Recommended)

...

---

## Minor Issues (Optional Polish)

...

---

## Prioritized Remediation Plan

1. **{ID}** — {one-line fix} (Impact: highest)
2. **{ID}** — {one-line fix} (Impact: high)
3. **{ID}** — {one-line fix} (Impact: medium)

---

## Positive Findings

- ✅ {what the skill does well}
- ✅ {another strength}
```

---

## Verdict Thresholds

| Overall Score | Verdict | Emoji | Next Action |
|---------------|---------|-------|-------------|
| 90-100 | Excellent | 🟢 | Deploy. Minor polish optional. |
| 80-89 | Good | 🟢 | Fix top 2-3 issues, then deploy. |
| 70-79 | Acceptable | 🟡 | Fix all Medium+ severity issues before deploy. |
| 60-69 | Needs Work | 🟠 | Major restructuring required. |
| Below 60 | Reject | 🔴 | Restart from pattern selection. |
