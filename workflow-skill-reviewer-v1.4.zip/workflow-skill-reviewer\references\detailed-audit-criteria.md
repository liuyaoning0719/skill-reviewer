# Detailed Audit Criteria

24+ detection items with specific methods, thresholds, and severity ratings.

Inspired by the CoPaw skill-workflow-audit framework, adapted for Kimi CLI and Agent Skills spec.

---

## T — Trigger Accuracy (2 items)

### T1: Description is the Only Trigger
**Severity**: Critical
**Detection**: Agents decide whether to load a skill based **solely** on frontmatter `description`. The body is only read AFTER activation.
**Threshold**: Description must contain:
- WHAT: what the skill does (functional description)
- WHEN: explicit trigger keywords and scenarios
- NOT: negative triggers with named alternatives
**Method**: Read only the description in isolation. Can you tell exactly when this skill should fire?
**Example (bad)**: `"React skills."`
**Example (good)**: `"Creates React components using Tailwind. Use when updating UI logic. Don't use for Vue."`

### T2: Trigger Keywords Missing or Vague
**Severity**: Critical
**Detection**: Description lacks specific action verbs or domain terms that match user phrasing.
**Method**: Generate 3 realistic prompts that should trigger; if description alignment < 80%, flag.
**Fix**: Add explicit trigger keyword list in description.

---

## S — Structural & Specification (8 items)

### S1: Frontmatter Malformed
**Severity**: Critical
**Detection**: Missing `---` YAML block, missing `name` or `description`.
**Method**: Check file starts with `---` and contains both required fields.

### S2: Name Not Kebab-Case
**Severity**: Major
**Detection**: `name` contains uppercase, underscores, spaces, or non-ASCII.
**Method**: Regex `^[a-z0-9]+(-[a-z0-9]+)*$`
**Fix**: Convert to lowercase with hyphens only.

### S3: Description Too Long
**Severity**: Minor
**Detection**: `description` ≥ 1024 characters.
**Method**: `len(description) > 1024`
**Fix**: Move details to body; keep description as trigger-only.

### S4: Description Contains XML/HTML
**Severity**: Major
**Detection**: `description` contains `<` or `>` characters.
**Method**: `'<' in description or '>' in description`
**Fix**: Use plain text; XML in description corrupts YAML parsing.

### S5: Folder Name Mismatch
**Severity**: Minor
**Detection**: Parent directory name ≠ `name` field.
**Method**: Compare `os.path.basename(dir)` with `frontmatter['name']`

### S6: Description Incomplete (Missing WHAT or WHEN)
**Severity**: Major
**Detection**: No functional sentence (WHAT) or no trigger clause (WHEN).
**Method**: Check for verb-led functional description + "Use when" / "Triggers on" clause.

### S7: Description Monolingual (when bilingual expected)
**Severity**: Moderate
**Detection**: Only English or only Chinese triggers in a bilingual team.
**Method**: Check for both ASCII and CJK characters in description.
**Note**: Optional; skip if team is single-language.

### S8: File Structure Non-Standard
**Severity**: Minor
**Detection**: `README.md`, `CHANGELOG.md`, or other human-facing docs exist in skill dir.
**Method**: `glob(skill_dir, "README*")` or `CHANGELOG*`

---

## C — Content Quality & Coverage (5 items)

### C1: Claimed Coverage Missing
**Severity**: Major
**Detection**: Skill claims "comprehensive" or "all" but covers only a subset.
**Method**: Compare stated scope in description/principles against actual body coverage.
**Example (bad)**: `"Handles all PDF operations"` but only covers extraction.

### C2: Input/Output Format Missing
**Severity**: Major
**Detection**: Skill processes data but never specifies expected input shape or output format.
**Method**: Check for format specifications, schema examples, or template references.

### C3: Format Mismatch
**Severity**: Major
**Detection**: Script expects `.json` but skill docs say `.md`; or vice versa.
**Method**: Cross-check `scripts/` file extensions with skill instructions.

### C4: Dependencies Undeclared
**Severity**: Major
**Detection**: Skill uses external tools/scripts but doesn't declare them.
**Method**: Check if `scripts/` files have imports not covered by allowed-tools.

### C5: Threshold Too Loose
**Severity**: Moderate
**Detection**: Quality gates are so loose they never fail.
**Method**: Check if thresholds like "< 1000 lines" when skill is 800 lines (should be < 500).

---

## D — Atomic Degradation (4 items)

Applies primarily to simple (atomic) skills, but relevant for all.

### D1: Core Logic Displaced to Script
**Severity**: Critical
**Detection**: The skill's judgment/prompt logic lives in a Python script instead of SKILL.md.
**Method**: Check if `scripts/` contains decision logic that should be in the prompt.
**Rationale**: A skill's value is in prompt wisdom. Scripts lose the LLM's judgment capability.

### D2: Skill Calls Other Skills (Atomic Violation)
**Severity**: Major
**Detection**: An atomic skill declares dependencies on other skills instead of tools.
**Method**: Check `requires` or references to other skill names in body.

### D3: Scope Too Broad (Atomic Violation)
**Severity**: Major
**Detection**: Description contains "and"/"then"/"+" connecting multiple independent purposes.
**Method**: Check for conjunctions linking distinct workflows.
**Fix**: Split into multiple skills or use Routing pattern.

### D4: Missing Determinism
**Severity**: Major
**Detection**: Multiple "if" branches in description without clear routing logic.
**Method**: Check for unmapped conditional words: "如果"/"根据"/"情况"/"depending on".
**Fix**: Use Routing pattern with explicit decision table.

---

## A — AGENTS.md Quality (6 items)

### A1: AGENTS.md Too Large (Context Rot)
**Severity**: Major
**Detection**: AGENTS.md > 150 lines without progressive disclosure.
**Threshold**: > 150 lines = risk of context pollution; > 300 lines = high risk.
**Rationale**: Agent opens dozens of referenced docs → context pollution → completeness drops.

### A2: Missing Step-by-Step Workflow
**Severity**: Major
**Detection**: AGENTS.md describes modules but gives no numbered workflow.
**Method**: Check for "Step N:" or "Phase N:" markers.

### A3: Missing Decision Table
**Severity**: Moderate
**Detection**: Architecture has ambiguous choices but no decision matrix.
**Method**: Check for tables mapping scenarios to actions.
**Fix**: Add decision table: "If scenario A → action X; If scenario B → action Y"

### A4: No Real Code Snippets
**Severity**: Moderate
**Detection**: Only prose descriptions, no concrete code/config examples.
**Method**: Check for fenced code blocks with realistic (not placeholder) content.

### A5: Too Many Domain Rules
**Severity**: Moderate
**Detection**: > 10 domain-specific rules in AGENTS.md.
**Threshold**: > 10 rules = cognitive overload; move to references/.

### A6: Prohibition-Only Guidance
**Severity**: Major
**Detection**: Only "Don't do X" without "Do Y instead".
**Method**: Check ratio: prohibition statements vs positive action statements.
**Fix**: Every "Don't X" must pair with "Use Y instead".

---

## X — Cross-Skill Collaboration (6 items)

Requires access to multiple skills in the same workflow.

### X1: Functional Overlap
**Severity**: Critical
**Detection**: Two skills in the same workflow have similar descriptions or capabilities.
**Method**: Keyword overlap analysis on descriptions within workflow scope.

### X2: Dependency Omission
**Severity**: Major
**Detection**: A workflow skill references atoms but doesn't declare all dependencies.
**Method**: Compare `requires` / referenced skills against actual mentions in body.

### X3: Interface Mismatch
**Severity**: Major
**Detection**: Skill A outputs format X, Skill B expects format Y.
**Method**: Cross-check output specs of upstream skill with input specs of downstream skill.

### X4: Version Inconsistency
**Severity**: Moderate
**Detection**: Workflow contains skills with incompatible versions.
**Method**: Check version metadata across skills in same workflow.

### X5: Naming Conflict
**Severity**: Moderate
**Detection**: Two skills have similar names causing misfires.
**Method**: Levenshtein distance < 3 between skill names in same scope.

### X6: Redundant Skill
**Severity**: Minor
**Detection**: One skill's functionality is completely covered by another.
**Method**: Check if description A is a subset of description B.

---

## F — Freedom Calibration (3 items)

### F1: Over-Constrained Execution Order
**Severity**: Moderate
**Detection**: Skill mandates a rigid step sequence without flexibility for user intent.
**Method**: Check for phrases like "must execute in order", "strictly follow steps", "never skip" without a flexibility clause.
**Fix**: Add "If user explicitly specifies a different order, prioritize user intent."
**Example (bad)**: "You must first confirm the phone number, then confirm the time, then submit."
**Example (good)**: "Usually confirm phone → time → submit, but if user specifies otherwise, follow their intent."

### F2: Missing Flexibility Fallback
**Severity**: Minor
**Detection**: Constraints exist but no escape hatch for edge cases.
**Method**: Every rigid rule should be paired with a conditional exception.

### F3: Dangerous Hooks Always Loaded
**Severity**: Moderate
**Detection**: Destructive action confirmations (delete, cancel, overwrite) are hardcoded in main flow rather than triggered on-demand.
**Method**: Check if safety gates run on every invocation or only when dangerous action is imminent.
**Fix**: Use conditional hooks: "Before DELETE operations, prompt user confirmation."

---

## G — Gotchas & Experience (5 items)

### G1: Missing Gotchas Section
**Severity**: Moderate
**Detection**: No "Gotchas", "Caveats", "Pitfalls", or "踩坑点" section exists.
**Rationale**: Gotchas capture team-specific wisdom that models cannot infer. They prevent repeated real-world failures.

### G2: Gotchas Are Generic Knowledge
**Severity**: Minor
**Detection**: Gotchas contain universal facts ("HTTP requests need headers", "JSON has key-value pairs").
**Method**: Ask "Would a pre-trained model already know this?" If yes, it's noise.
**Fix**: Replace with domain-specific edge cases ("Token cache at ~/.eac/ expires in 30min, refresh via /api/refresh").

### G3: Irreversible Operations Without Confirmation
**Severity**: Major
**Detection**: Delete, cancel, overwrite, revoke actions lack user confirmation step.
**Method**: Search for destructive verbs (delete, drop, cancel, revoke, overwrite) without preceding confirmation check.

### G4: Auth/Token Expiry Not Documented
**Severity**: Major
**Detection**: Skill uses authenticated APIs but doesn't explain token lifecycle or refresh mechanism.
**Method**: Check if authentication section mentions expiry, refresh, or fallback when creds fail.

### G5: Rate Limits Not Documented
**Severity**: Minor
**Detection**: Skill calls external APIs without mentioning rate limits or backoff strategy.

---

## Three-Layer Reliability Constraints

Based on the Skill Graph 2.0 framework:

| Layer | Characteristics | Max Chain Length | Constraint |
|:---|:---|:---:|:---|
| **Atom** | Single purpose, near-deterministic | 1x | Must NOT call other skills |
| **Molecule** | Orchestrates 2-10 atoms | 10x | Combine logic compressed into skill itself |
| **Compound** | High-level intent, drives molecules | 100x | Needs human oversight; ≤10 molecules |

**Reliability formula**: 
- Atom failure → entire chain collapses
- Molecule with >10 atoms → reliability ceiling hit
- Compound with >10 molecules → requires human-in-the-loop

**Audit rule**: 
- If skill claims to be "atomic" but calls other skills → D2 violation
- If molecule orchestrates >10 atoms → T2 violation  
- If compound auto-triggers without user intent → design risk

---

## Severity Definitions

| Level | Meaning | Deployment Blocker? |
|:---|:---|:---:|
| **Critical** | Will cause misfires, failures, or unreliable execution | Yes |
| **Major** | Significantly degrades reliability or maintainability | Strongly recommended |
| **Moderate** | Reduces quality; fix before wide adoption | Recommended |
| **Minor** | Polish issue; nice to have | Optional |

---

## Document Discovery Rates

Based on observed agent behavior:

| Location | Discovery Rate |
|:---|:---:|
| AGENTS.md / SKILL.md | ~100% |
| Directly linked from AGENTS.md / SKILL.md | ~80% |
| Inline code comments | ~40% |
| Orphaned docs (`_docs/`, unlinked) | < 10% |

**Rule**: Every important instruction must be in SKILL.md or directly linked from it. Orphaned documentation is effectively invisible to agents.
