# Anti-Patterns Catalog

20 common mistakes in workflow skills with severity, before/after examples, and fixes.

---

## AP-1: Missing Goals / Anti-Goals
**Severity**: Critical
**Pattern**: Any

**Before**:
```markdown
# Code Review Skill

Review code for quality issues.
```

**After**:
```markdown
## When to Use
- Reviewing PRs for security, performance, or maintainability
- Pre-commit quality checks

## When NOT to Use
- Simple linting (use eslint/pylint directly)
- Rewriting entire architectures (use architecture-review skill)
- Non-code artifacts (use doc-review skill)
```

---

## AP-2: Monolithic SKILL.md (>500 lines)
**Severity**: Critical
**Pattern**: Any

**Before**: Single 900-line SKILL.md with all API docs, schemas, and examples inline.

**After**:
```
skill-name/
├── SKILL.md (120 lines: principles + routing)
├── references/
│   ├── api-docs.md
│   ├── schema.md
│   └── examples.md
└── scripts/
    └── generate-report.py
```

---

## AP-3: Reference Chains (A → B → C)
**Severity**: High
**Pattern**: Any

**Before**:
```markdown
See [details](references/overview.md)
```
Then in `references/overview.md`:
```markdown
See [schema](db/v1/schema.md)
```

**After**:
```markdown
See [API details](references/api-docs.md)
See [Database schema](references/schema.md)
```
All links directly from SKILL.md. Flat structure.

---

## AP-4: Hardcoded Paths
**Severity**: High
**Pattern**: Any

**Before**:
```markdown
Run: python /home/user/projects/skill/scripts/setup.py
```

**After**:
```markdown
Run: python {baseDir}/scripts/setup.py
```

---

## AP-5: Broken File References
**Severity**: High
**Pattern**: Any

**Before**:
```markdown
See [cheatsheet](references/cheatsheet.md)  # File does not exist
```

**After**:
```markdown
See [cheatsheet](references/cheatsheet.md)  # Verified existing
```

**Fix**: Before submitting, verify every referenced path resolves.

---

## AP-6: Unnumbered Phases
**Severity**: Critical
**Pattern**: Linear, Pipeline, Safety Gate

**Before**:
```markdown
First analyze the code. Then check for issues. Finally generate a report.
```

**After**:
```markdown
### Phase 1: Analysis
**Entry**: Code files are identified.
**Actions**:
1. Read each modified file.
2. Identify change types.
**Exit**: Change list documented.

### Phase 2: Issue Detection
**Entry**: Change list is complete.
**Actions**:
1. Check for security risks.
2. Check for test coverage gaps.
**Exit**: Issue list populated.
```

---

## AP-7: Missing Exit Criteria
**Severity**: High
**Pattern**: Any with phases

**Before**:
```markdown
### Phase 1: Analyze code
Read the files and understand changes.
```

**After**:
```markdown
### Phase 1: Analyze Code
**Entry criteria**: Modified files identified via git diff or user input.
**Actions**:
1. Read each modified file.
2. Summarize change type per file.
**Exit criteria**: A numbered list of all modified files with change summaries exists.
```

---

## AP-8: No Verification Step
**Severity**: High
**Pattern**: Any

**Before**: Workflow ends after generation without checking output.

**After**:
```markdown
### Phase 4: Verification
**Entry**: Output files created.
**Actions**:
1. Verify all required sections exist.
2. Check no placeholder text remains.
3. Confirm file references resolve.
**Exit**: Verification checklist all checked.
```

---

## AP-9: Vague Routing Keywords
**Severity**: Medium
**Pattern**: Routing

**Before**:
```markdown
| Intent | Workflow |
|--------|----------|
| fix | workflows/fix.md |
| update | workflows/update.md |
```

**After**:
```markdown
| Intent | Trigger Keywords | Workflow |
|--------|-----------------|----------|
| bug-fix | "bug", "error", "crash", "fix" | workflows/bug-fix.md |
| dependency-update | "upgrade", "bump version", "update deps" | workflows/deps-update.md |
```

---

## AP-10: No Default / Fallback Route
**Severity**: Medium
**Pattern**: Routing

**Before**: Routing table with no fallback when intent is unclear.

**After**:
```markdown
If no route matches with >70% confidence, ask the user for clarification.
Do not guess the route.
```

---

## AP-11: Wrong Tool for the Job
**Severity**: High
**Pattern**: Any

**Before**:
```markdown
Use Bash `find` to locate all Python files.
Use Bash `grep` to search for patterns.
```

**After**:
```markdown
Use Glob to find Python files.
Use Grep to search for patterns.
```

---

## AP-12: Overprivileged Tools
**Severity**: Medium
**Pattern**: Any

**Before**: Read-only analysis skill declares `Write`, `Bash`, `Edit`.

**After**:
```yaml
allowed-tools:
  - Read
  - Glob
  - Grep
  - TodoRead
  - TodoWrite
```

---

## AP-13: Vague Subagent Prompts
**Severity**: High
**Pattern**: Task-Driven, Pipeline

**Before**:
```markdown
Spawn a subagent to analyze the code.
```

**After**:
```markdown
Spawn an Explore subagent with:
- Task: Find all authentication-related code patterns
- Scope: src/auth/ and src/middleware/
- Return: A list of files, pattern types, and risk ratings (Low/Medium/High)
```

---

## AP-14: Missing Tool Justification
**Severity**: Low
**Pattern**: Any

**Before**: Tools listed with no explanation.

**After**:
```markdown
## Tools
- **Read / Glob / Grep**: File discovery and content analysis
- **Bash**: Running test suites and build commands (no dedicated tool exists)
- **AskUserQuestion**: Confirming destructive actions before execution
```

---

## AP-15: Reference Dumps
**Severity**: Medium
**Pattern**: Any

**Before**: Pasting 200 lines of API documentation directly into SKILL.md.

**After**:
```markdown
For complete API parameter reference, see `references/api-params.md`.
Load only the endpoint section relevant to the current task.
```

---

## AP-16: Missing Rationalizations
**Severity**: Medium
**Pattern**: Audit, Review, Decision skills

**Before**: Skill makes judgments without explaining rejection criteria.

**After**:
```markdown
## Rationalizations to Reject
| Claim | Why It's Wrong |
|-------|---------------|
| "It's obvious which phase comes next" | LLMs don't infer ordering from prose. Number the phases. |
| "Exit criteria are implied" | Implied criteria are skipped criteria. Write them explicitly. |
```

---

## AP-17: No Concrete Examples
**Severity**: High
**Pattern**: Any

**Before**:
```markdown
Generate a conventional commit message.
```

**After**:
```markdown
Generate a conventional commit message.

**Example**:
- Input: `git diff` showing added login feature
- Output: `feat(auth): add OAuth2 login with Google provider`

**Template**: `type(scope): description [body] [footer]`
```

---

## AP-18: Cartesian Product Tool Calls
**Severity**: High
**Pattern**: Pipeline, Task-Driven

**Before**: Search 10 files for 5 patterns → 50 separate Grep calls.

**After**: Combine into one regex with alternation, Grep once, then filter results.

```markdown
Use a single Grep with pattern `(pattern1|pattern2|pattern3|pattern4|pattern5)`.
Process the combined results to categorize by matched pattern.
```

---

## AP-19: Unbounded Subagent Spawning
**Severity**: High
**Pattern**: Task-Driven, Pipeline

**Before**: Spawn one subagent per file in a 500-file repo.

**After**: Batch files into groups of 10-20, spawn one subagent per batch.

```markdown
Batch files by directory. Spawn one subagent per batch with the file list.
Aggregate results after all batches complete.
```

---

## AP-20: Description Summarizes Workflow
**Severity**: Critical
**Pattern**: Any

**Before**:
```yaml
description: |
  This skill first checks out the code, then runs tests, 
  then deploys to production. Use it for releases.
```

**After**:
```yaml
description: |
  Automates production release workflow including version bump, 
  changelog generation, and deployment. Use when the user asks 
  to release, deploy to prod, or cut a new version. 
  Don't use for staging deployments or hotfix workflows.
```

**Key rule**: Description = triggering conditions. Never workflow steps.
