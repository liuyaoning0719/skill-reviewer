# Review Checklist

Structured self-review checklist for workflow skill authors and reviewers.

Copy this checklist into a task or todo list when auditing a skill.

---

## Section T: Trigger Accuracy

- [ ] `name` matches parent directory name exactly
- [ ] `name` uses only lowercase letters, digits, and hyphens
- [ ] `name` is 1-64 characters long
- [ ] `description` is ≤ 1024 characters
- [ ] `description` uses third-person phrasing
- [ ] `description` includes WHAT the skill does (functional description)
- [ ] `description` includes WHEN to use it (trigger keywords/scenarios)
- [ ] `description` includes negative triggers ("Don't use for...")
- [ ] `description` does NOT summarize workflow steps
- [ ] `description` contains no XML/HTML tags (`<`, `>`)
- [ ] Frontmatter contains `name` and `description`

**Score**: ___ / 11 → Weighted: ___

---

## Section S: Structure & Specification

- [ ] Skill follows one recognizable pattern: Linear / Pipeline / Routing / Safety Gate / Task-Driven
- [ ] All phases/steps are numbered (no gaps, no 2b-style decimals)
- [ ] Every phase has entry criteria (what must be true before starting)
- [ ] Every phase has numbered actions (what to do)
- [ ] Every phase has exit criteria (how to know it's done)
- [ ] Every branch ultimately leads to an END or explicit termination
- [ ] Flow skills have clearly marked BEGIN and END nodes
- [ ] No mixing of patterns without explicit explanation
- [ ] SKILL.md < 500 lines
- [ ] SKILL.md < 300 lines (ideal)
- [ ] No human-facing documentation files (README, CHANGELOG, etc.)
- [ ] Detailed docs live in `references/` directory
- [ ] Scripts live in `scripts/` directory
- [ ] All references are one hop from SKILL.md (no A→B→C chains)
- [ ] No duplication between SKILL.md and reference files
- [ ] Large reference files (>100 lines) have a table of contents

**Score**: ___ / 16 → Weighted: ___

---

## Section C: Content Quality & Coverage

- [ ] Instructions use third-person imperative ("Extract...", "Verify...")
- [ ] No vague commands ("analyze", "fix") without specificity
- [ ] Fragile steps use exact commands or scripts (low freedom)
- [ ] Variable steps provide heuristics with examples (high freedom)
- [ ] At least one concrete input/output example exists
- [ ] Essential principles explain WHY, not just WHAT
- [ ] A verification step exists at the end of every workflow path
- [ ] Error handling and failure modes are documented
- [ ] No assumptions that the agent "will figure it out"
- [ ] Claimed coverage matches actual body content (no over-promising)
- [ ] Input/output formats are specified where applicable
- [ ] No hardcoded absolute paths

**Score**: ___ / 12 → Weighted: ___

---

## Section D: Drift Resistance & Resilience

- [ ] Destructive actions have confirmation gates
- [ ] Script failures have documented fallbacks
- [ ] Empty/missing inputs have handling instructions
- [ ] Subagent failures have retry or escalation paths
- [ ] Edge cases are acknowledged
- [ ] Unsupported configurations are explicitly called out
- [ ] Loops have maximum iteration guards
- [ ] Partial failure is handled gracefully (don't all-or-nothing)

**Score**: ___ / 8 → Weighted: ___

---

## Section X: Tools & Permissions

- [ ] Skill declares only tools it actually uses (allowed-tools or tools)
- [ ] Bash is not used for file operations that have dedicated tools
- [ ] Read-only skills do not declare Write or Bash
- [ ] Each declared tool can be justified with a specific use case
- [ ] No over-privileging (e.g., declaring Edit when only Read is needed)
- [ ] No under-privileging (e.g., missing AskUserQuestion for interactive steps)

**Score**: ___ / 6 → Weighted: ___

---

## Section A: Scope & AGENTS.md (if applicable)

- [ ] Skill has a single, clear purpose
- [ ] Name reflects one job
- [ ] No unrelated functionality bundled
- [ ] Multi-purpose skills use Routing pattern with clear separation
- [ ] If AGENTS.md exists: ≤ 150 lines or uses progressive disclosure
- [ ] If AGENTS.md exists: has numbered workflows
- [ ] If AGENTS.md exists: has decision tables for ambiguous choices
- [ ] If AGENTS.md exists: every prohibition has a positive alternative

**Score**: ___ / 8 → Weighted: ___

---

## Section F: Freedom Calibration

- [ ] Execution order constraints have flexibility fallback ("unless user specifies otherwise")
- [ ] Rigid rules are paired with conditional exceptions
- [ ] Dangerous operations use on-demand hooks, not always-loaded guards
- [ ] Model has adaptive space for variable tasks (heuristics, not hardcoded sequences)

**Score**: ___ / 4 → Weighted: ___

---

## Section G: Gotchas & Experience

- [ ] Has a Gotchas / Caveats / Pitfalls section
- [ ] Gotchas contain team-specific wisdom, not generic knowledge
- [ ] Destructive operations (delete, cancel, overwrite) have user confirmation
- [ ] Auth/Token expiry and refresh mechanism are documented
- [ ] API rate limits or backoff strategy are mentioned

**Score**: ___ / 5 → Weighted: ___

---

## Three-Layer Architecture Check

Determine skill layer and verify constraints:

- [ ] **Atom**: Does NOT call other skills; single purpose; near-deterministic
- [ ] **Molecule**: Orchestrates ≤ 10 atoms; combination logic is explicit in skill
- [ ] **Compound**: Drives ≤ 10 molecules; requires human oversight; not auto-triggered

**Score**: ___ / 3 → Weighted: ___

---

## Issue ID Quick Reference

Map findings to standardized IDs for consistent reporting:

| ID | Issue | Category |
|:---|:---|:---|
| T1 | Description is the only trigger | Trigger |
| T2 | Trigger keywords missing/vague | Trigger |
| S1 | Frontmatter malformed | Structure |
| S2 | Name not kebab-case | Structure |
| S3 | Description too long | Structure |
| S4 | Description contains XML | Structure |
| S5 | Folder name mismatch | Structure |
| S6 | Description incomplete | Structure |
| S7 | Description monolingual | Structure |
| S8 | File structure non-standard | Structure |
| C1 | Claimed coverage missing | Content |
| C2 | Input/output format missing | Content |
| C3 | Format mismatch | Content |
| C4 | Dependencies undeclared | Content |
| C5 | Threshold too loose | Content |
| D1 | Core logic displaced to script | Atomic |
| D2 | Skill calls other skill (atomic) | Atomic |
| D3 | Scope too broad | Atomic |
| D4 | Missing determinism | Atomic |
| A1 | AGENTS.md too large | AGENTS.md |
| A2 | Missing step-by-step workflow | AGENTS.md |
| A3 | Missing decision table | AGENTS.md |
| A4 | No real code snippets | AGENTS.md |
| A5 | Too many domain rules | AGENTS.md |
| A6 | Prohibition-only guidance | AGENTS.md |
| X1 | Functional overlap | Cross-skill |
| X2 | Dependency omission | Cross-skill |
| X3 | Interface mismatch | Cross-skill |
| X4 | Version inconsistency | Cross-skill |
| X5 | Naming conflict | Cross-skill |
| X6 | Redundant skill | Cross-skill |
| AP-1~AP-20 | Anti-patterns | General |

---

## Score Calculation

| Section | Weight | Raw (max) | Raw Score | Weighted |
|---------|--------|-----------|-----------|----------|
| T: Trigger | 20% | 11 | | |
| S: Structure | 20% | 16 | | |
| C: Content | 20% | 12 | | |
| D: Drift | 10% | 8 | | |
| X: Tools | 10% | 6 | | |
| A: Scope | 5% | 8 | | |
| **Total** | **100%** | | | |

---

## Verdict

| Total Score | Verdict | Next Action |
|-------------|---------|-------------|
| 90-100 | Excellent | Deploy. Optional polish. |
| 80-89 | Good | Fix top 2-3 issues, then deploy. |
| 70-79 | Acceptable | Fix all Medium+ severity issues. |
| 60-69 | Needs Work | Major restructuring required. |
| Below 60 | Reject | Restart from pattern selection. |
