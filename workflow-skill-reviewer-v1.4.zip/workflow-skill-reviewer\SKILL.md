---
name: workflow-skill-reviewer
description: |
  Reviews and audits workflow-based agent skills (Flow Skills and multi-step standard skills) for
  structural quality, pattern adherence, tool correctness, ASI-friendliness, resilience, and security.
  Use when evaluating, auditing, scoring, or improving any SKILL.md that defines multi-step workflows
  or phased execution. Validates Mermaid/D2 flow diagrams, description information density,
  timeout/retry/fallback coverage, and credential isolation.
  Triggers on: skill review, skill audit, workflow quality check, SKILL.md evaluation, flow skill
  validation, 评审技能, 检查技能质量, 技能审查, 技能规范检查, 工作流评审.
  Do NOT use for simple single-purpose skills with no workflow phases
  (use general code review instead), for plugin/hook configuration questions,
  for non-skill agent development, or for reviewing Agent execution logs
  (use execution-audit instead).
allowed-tools:
  - ReadFile       # read SKILL.md, references/, and scripts/
  - Shell          # run validate_skill.py on target skill
  - AskUserQuestion # confirm audit scope or focus areas
---

# Workflow Skill Reviewer v1.4

Reviews workflow-based agent skills against industry best practices and produces structured audit reports.

## 与 execution-audit 的区别

| 维度 | workflow-skill-reviewer | execution-audit |
|:---|:---|:---|
| **审查对象** | SKILL.md 文件（Skill 本身的设计与结构） | Agent 执行日志/输出（运行时行为） |
| **审查时机** | Skill 创建/更新/发布前 | Agent 执行 Skill 时或执行后 |
| **检测重点** | 结构模式、触发精准度、工具权限、渐进披露 | 执行偷懒、跳步、输出幻觉、过度工程化 |

## Essential Principles

1. **Description is the trigger** — Agents load skills based solely on YAML frontmatter. A bad description means wrong activations or missed activations regardless of body quality. Description must contain trigger keywords, use cases, and exclusions.

2. **Pattern over prose** — Unnumbered prose instructions produce unreliable execution order. Every workflow must follow a recognizable structural pattern with numbered phases, entry criteria, and exit criteria.

3. **Progressive disclosure** — SKILL.md is a navigation brain, not an encyclopedia. Keep it under 500 lines. Offload details to `references/` and `scripts/`. One level deep — no reference chains.

4. **Least privilege tools** — List only tools the skill actually uses. Never use Bash for operations that have dedicated tools (Glob, Grep, Read, Write, Edit).

5. **Calibrated freedom** — Match specificity to task fragility. Fragile operations need exact commands. Variable tasks need heuristics. Avoid over-constraining execution order when the model can adapt to user intent.

6. **Gotchas are experience** — Every skill should have a Gotchas section capturing team-specific pitfalls. Generic advice ("HTTP needs auth") is noise; specific edge cases ("Token X expires after 30min, refresh via endpoint Y") are signal.

## Gotchas

- **False negatives on short skills**: A skill with < 100 lines and no phases may score perfectly on structure but still be useless. Always verify the skill solves a real problem before giving high marks.
- **Pattern bias**: Do not force every skill into one of the 5 patterns. Some hybrid workflows are valid if clearly explained.
- **Platform differences**: `allowed-tools` is Kimi-specific; other platforms (Claude, Codex) use `tools:` instead. Adjust Phase 5 accordingly.
- **AGENTS.md scope creep**: This skill audits SKILL.md primarily. AGENTS.md checks (A1-A6) are secondary and only run when AGENTS.md is present in the project.
- **Self-audit blindness**: Reviewers often miss problems in their own skills. When auditing a skill you wrote, double-check Gotchas and freedom calibration.

## When to Use

- Auditing a new Flow Skill before publishing or team deployment
- Evaluating an existing standard skill that contains multi-step workflows
- Comparing two candidate skill implementations for the same workflow
- Refactoring a bloated SKILL.md into a well-structured workflow skill
- Teaching skill authors why their skill misfires or deviates from intended steps
- Performing quarterly quality sweeps of a skill repository

## When NOT to Use

- Simple single-purpose skills with no phases (use general review or `/skill:skill-creator`)
- Plugin configuration (plugin.json, hooks, commands) — use plugin development guides
- Non-skill agent development (agents.yaml, system prompts) — use agent design guides
- Evaluating the domain correctness of code inside scripts/ — use domain-specific review skills
- Reviewing Agent execution logs or runtime behavior — use execution-audit

## Review Dimensions

Apply these seven dimensions in priority order. Fidelity always wins ties.

| ID | Dimension | Priority | Core Question |
|:---|:---|:---|:---|
| T1 | **Trigger Accuracy** | Critical | Does the description activate at the right times and only then? |
| S1 | **Structural Fidelity** | Critical | Does it follow a recognizable pattern with numbered phases and clear criteria? |
| S2 | **Instruction Actionability** | High | Are steps deterministic enough to prevent agent hallucination? |
| S3 | **Context Efficiency** | High | Does it load only what's needed, when it's needed? |
| C1 | **Drift Resistance** | High | Does it hold shape on edge-case inputs and failure states? |
| S4 | **Tool Minimality** | Medium | Are tools precisely matched to the work with no over-privileging? |
| S5 | **Scope Coherence** | Medium | Is it focused on one workflow without scope creep? |

For detailed criteria, detection methods, and severity ratings per dimension, see `references/detailed-audit-criteria.md`.

## Review Workflow

### Phase 1: Structural Validation
**Entry criteria**: Skill directory and SKILL.md exist and are readable.
**Actions**:
1. Verify frontmatter contains `name` and `description`.
2. Verify `name` matches parent directory name; 1-64 chars; kebab-case only.
3. Verify description ≤ 1024 characters.
4. Verify SKILL.md < 500 lines.
5. Verify no forbidden files exist (README.md, CHANGELOG.md, etc.).
6. Verify directory structure is flat: `references/*`, `scripts/*`, `assets/*` are one level deep.
7. Run `scripts/validate_skill.py` if available in the target skill.

**Exit criteria**: Structural report with pass/warning/fail per check. If any critical check fails (e.g., missing SKILL.md), halt audit and report blocker immediately.

**Intermediate output**:
```json
{
  "phase": "structural_validation",
  "checks": { "frontmatter_present": true, "name_valid": true, "line_count": 219, "line_count_ok": true, "forbidden_files": [], "directory_depth_ok": true },
  "status": "pass"
}
```

### Phase 2: Trigger Analysis
**Entry criteria**: Frontmatter passed structural checks.
**Actions**:
1. Check description for third-person phrasing and specific trigger keywords.
2. Check for explicit negative triggers ("Don't use for...").
3. Generate 3 prompts that should trigger and 3 that should not; verify alignment.

**Exit criteria**: Trigger score (0-100) with concrete rewrite suggestions if < 80.

**Intermediate output**:
```json
{ "phase": "trigger_analysis", "score": 92, "has_positive_triggers": true, "has_negative_triggers": true, "suggested_rewrites": [] }
```

### Phase 3: Pattern Recognition
**Entry criteria**: SKILL.md body is loaded.
**Actions**:
1. Identify which of the 5 patterns applies. See `references/workflow-patterns.md`.
2. Verify the skill uses the pattern correctly:
   - Routing: has a routing table mapping intent to workflow files.
   - Sequential Pipeline: steps feed into each other; can resume from partial progress.
   - Linear Progression: single path; numbered phases with entry/exit criteria.
   - Safety Gate: two confirmation gates before destructive actions.
   - Task-Driven: uses task tracking with dependency management.
3. Flag unnumbered phases, missing entry/exit criteria, or mixed patterns without clarity.

**Exit criteria**: Pattern match verdict + specific skeleton gaps.

**Intermediate output**:
```json
{ "phase": "pattern_recognition", "detected_pattern": "Sequential Pipeline", "pattern_match_score": 92, "gaps": [] }
```

### Phase 4: Content Quality Audit
**Entry criteria**: Pattern is identified.
**Actions**:
1. Check for concrete input/output examples in the body.
2. Check that essential principles explain WHY, not just WHAT.
3. Check for a verification step at the end of every workflow.
4. Check for explicit error handling and failure modes.
5. Verify no hardcoded paths; use `{baseDir}` or relative paths.
6. Verify all file references resolve and are one hop from SKILL.md.
7. Scan for 20 common anti-patterns. See `references/anti-patterns.md`.
8. If AGENTS.md exists in the project, check for A1-A6 issues. See `references/agents-md-guide.md`.
9. Check freedom calibration (F1-F3): execution order constraints have flexibility fallbacks; dangerous operations use on-demand hooks. See `references/detailed-audit-criteria.md`.
10. Check Gotchas quality (G1-G5): Gotchas section exists, contains team-specific wisdom, destructive ops have confirmation, auth expiry documented, rate limits mentioned. See `references/detailed-audit-criteria.md`.

**Exit criteria**: Content score (0-100) + enumerated issues with line references.

**Intermediate output**:
```json
{ "phase": "content_quality", "score": 92, "issues_found": 1, "issues": [{"id": "AP-15", "line": 120, "severity": "medium", "msg": "Reference dump detected in Phase 4"}] }
```

### Phase 5: Tool Assignment Review
**Entry criteria**: Skill declares `allowed-tools` (Kimi) or `tools` (agents).
**Actions**:
1. Cross-check declared tools against actual instructions.
2. Flag unused tools (over-privileging) and missing tools (under-privileging).
3. Flag Bash used for file operations that have dedicated tools.
4. Verify read-only skills do not declare Write or Bash.

**Exit criteria**: Tool matrix with justification required for each declared tool.

**Intermediate output**:
```json
{ "phase": "tool_review", "declared_tools": ["SearchWeb", "FetchURL", "ReadFile", "Shell"], "used_tools": ["SearchWeb", "FetchURL", "ReadFile", "Shell"], "unused_tools": [], "missing_tools": [], "bash_misuse": false }
```

### Phase 6: Scoring & Reporting
**Entry criteria**: All prior phases complete.
**Actions**:
1. Compute weighted score across 7 dimensions.
2. Produce graded audit report:
   - 90-100%: Conforms well to best practices; minor polish optional.
   - 80-89%: Good skill; fix top 2-3 issues before deploy.
   - 70-79%: Acceptable; fix all Medium+ severity issues before deploy.
   - 60-69%: Needs work; major restructuring required.
   - Below 60%: Reject; restart from pattern selection.
3. List prioritized remediation steps (highest impact first).
4. Include before/after examples for top 3 issues.
5. **Verify report completeness**: Confirm every dimension has at least one observation, every issue has a line reference, and the overall score matches the weighted calculation.

**Exit criteria**: Final report delivered to user and verified complete.

**Report template**: See `references/audit-report-template.md`.

## Anti-Pattern Quick Reference

| ID | Anti-Pattern | Severity | One-Line Fix |
|:---|:---|:---:|:---|
| AP-1 | Missing When to Use / When NOT to Use | Critical | Add both sections with named alternatives |
| AP-2 | Monolithic SKILL.md (>500 lines) | Critical | Split into `references/` and `workflows/` |
| AP-3 | Reference chains (A → B → C) | High | Ensure all links are one hop from SKILL.md |
| AP-4 | Hardcoded paths | High | Use `{baseDir}` or relative paths |
| AP-5 | Broken file references | High | Verify every path resolves |
| AP-6 | Unnumbered phases | Critical | Number every phase with entry/exit criteria |
| AP-7 | Missing exit criteria | High | Define what "done" means for each phase |
| AP-8 | No verification step | High | Add validation at the end of every workflow |
| AP-9 | Vague routing keywords | Medium | Use distinctive keywords per route |
| AP-10 | Description summarizes workflow | Critical | Description = triggering conditions only |
| AP-11 | Wrong tool for the job | High | Use Glob/Grep/Read, not Bash equivalents |
| AP-12 | Overprivileged tools | Medium | Remove tools not actually used |
| AP-13 | Vague subagent prompts | High | Specify what to analyze, look for, and return |
| AP-14 | Missing tool justification | Low | Add why each tool is needed |
| AP-15 | Reference dumps | Medium | Teach judgment, not raw documentation |
| AP-16 | Missing rationalizations | Medium | Add "Rationalizations to Reject" for audit skills |
| AP-17 | No concrete examples | High | Show input → output for key instructions |
| AP-18 | Cartesian product tool calls | High | Combine patterns into single regex, grep once |
| AP-19 | Unbounded subagent spawning | High | Batch items into groups, one subagent per batch |
| AP-20 | Frontmatter description too vague | Critical | Include trigger keywords + negative triggers |
| AP-21 | Requires Ghost | High | Remove missing skill from `requires` or create it |
| AP-22 | Script Duplication | Medium | Remove duplicate scripts; keep canonical copy in one skill |
| AP-23 | Architecture Semantic Drift | High | Align directory structure with documented layers |
| AP-24 | Flow Diagram Missing | Critical | Add Mermaid/D2 diagram with BEGIN/END nodes |
| AP-25 | Description Leaks Implementation | High | Move scripts/references/steps from description to body |
| AP-26 | Missing Resilience Mechanisms | High | Add timeout/retry/fallback and sensitive-op confirmation |
| AP-27 | Hardcoded Credentials | Critical | Use placeholders (`{{API_KEY}}`, `YOUR_TOKEN`); never hardcode secrets |

## Rationalizations to Reject

When auditing skills, reject these shortcuts:

| Excuse | Issue | Correct Action |
|:---|:---|:---|
| "Python scripts are more reliable" | D1 — Atomic logic displaced | A skill's value is in prompt wisdom; scripts lose judgment logic |
| "The description doesn't matter much" | T1 — Trigger failure | Description is the ONLY trigger mechanism; bad description = invisible skill |
| "One big SKILL.md is simpler" | AP-2 — Monolithic bloat | Simpler to write, worse to execute; LLM loses focus past 500 lines |
| "Exit criteria are implied" | AP-7 — Missing criteria | Implied criteria are skipped criteria; write them explicitly |
| "Bash can do everything" | AP-11 — Wrong tool | Bash file ops are fragile; dedicated tools handle encoding/permissions better |
| "The LLM will figure out the tools" | AP-12 — Overprivileged | It will guess wrong; specify exactly which tool for each operation |
| "Users know what to do" | A6 — Prohibition-only | Only "don't" = no guidance; always pair with "do this instead" |
| "Feature overlap doesn't matter" | X1 — Redundancy | Overlap = Agent doesn't know which to call; behavior becomes chaotic |
| "The required skill will be added later" | AP-21 — Requires Ghost | Undeclared dependency = runtime failure; create stub or remove reference |
| "Scripts are idempotent so duplicates are fine" | AP-22 — Script Duplication | Divergence risk: one copy changes, the other doesn't; agent picks wrong one |
| "The layer names are just documentation" | AP-23 — Semantic Drift | If SKILL.md says atoms/molecules/compounds, the filesystem must reflect it |
| "Flow skills don't need diagrams" | AP-24 — Flow Diagram Missing | Flow skills MUST have Mermaid/D2 diagrams with BEGIN/END; no diagram = broken flow |
| "Description can mention scripts/" | AP-25 — Description Leaks | Description is loaded at startup; mentioning scripts/ wastes tokens and leaks internals |
| "The tool will always succeed" | AP-26 — Missing Resilience | Tools fail. Always specify timeout, retry, fallback, and destructive-op confirmation |
| "I'll configure credentials later" | AP-27 — Hardcoded Credentials | Placeholders (`{{KEY}}`) ship now; hardcoded secrets ship to production and leak |
| "I'll add details later" | — Incomplete design | Incomplete skills ship incomplete; design fully before writing |

## Tool Assignment Matrix

| Skill Type | Typical Tools |
|:---|:---|
| Read-only analysis | Read, Glob, Grep, TodoRead, TodoWrite |
| Interactive analysis | Read, Glob, Grep, AskUserQuestion, TodoRead, TodoWrite |
| Code generation | Read, Glob, Grep, Write, Bash, TodoRead, TodoWrite |
| Pipeline / Workflow | Read, Write, Glob, Grep, Bash, AskUserQuestion, Task, TaskCreate, TaskList, TaskUpdate, TodoRead, TodoWrite |

## Reference Index

| File | Content |
|:---|:---|
| `references/evaluation-rubric.md` | Full 7-dimension rubric with scoring rules and quality gates |
| `references/detailed-audit-criteria.md` | 24+ detection items with methods, thresholds, and severity ratings |
| `references/anti-patterns.md` | 27 anti-patterns with before/after fixes |
| `references/review-checklist.md` | Printable self-review checklist for skill authors |
| `references/workflow-patterns.md` | 5 patterns with structural skeletons and Mermaid/D2 examples |
| `references/agents-md-guide.md` | AGENTS.md audit criteria (A1-A6) and best practices |
| `references/audit-report-template.md` | Structured report template with JSON + Markdown formats |

## Success Criteria

A review produced by this skill is considered successful when it:

- Covers all 7 dimensions (T/S1/S2/S3/C1/S4/S5) plus F/G sub-dimensions with at least one concrete observation per dimension
- Identifies the correct workflow pattern or explains why none fits
- Provides at least 3 prioritized, actionable remediation steps
- Includes specific line references or file paths for every issue flagged
- Assigns an overall score with a clear threshold-based verdict
- Offers before/after examples for the highest-priority issues
- Verifies the audit report itself is complete before delivery

## Suite Mode（工作流套件审查）

When reviewing a **workflow suite** — a directory containing multiple related skills (e.g. atoms + molecules + compounds) — use `--suite` mode:

```bash
python validate_skill.py --suite <suite-directory>
```

**Suite mode performs two phases:**

### Phase A: Individual Skill Validation
Each sub-directory with a `SKILL.md` is validated as an independent skill (all 20 checks). Every skill must be **flat (one level deep)**.

### Phase B: Cross-Skill Relationship Analysis

| Check | Description | Fail Condition |
|:---|:---|:---|
| **Dependency Resolution** | All `requires` must point to skills within the suite | External dependency = suite boundary violation |
| **Requires Ghost** | Every `requires` must resolve to an existing sibling directory | Missing skill = runtime failure |
| **Layer Mapping** | Detect atom/molecule/compound layers from directory names | Unrecognized layer = "unknown" |
| **Call Direction** | compound → molecule → atom is valid; reverse is not | atom calling compound = architecture violation |
| **Circular Dependency** | No cycles in requires graph | Cycle = infinite loop risk |
| **Script Duplication** | Same `.py` in multiple skill `scripts/` | Divergence risk + boundary confusion |

**Example valid suite:**
```
my-workflow-suite/
├── my-workflow/          ← compound (requires: my-molecules)
├── my-molecules/         ← molecule (requires: my-atoms)
└── my-atoms/             ← atom (no requires)
```

**Key principle:** A skill suite is **not** a single skill with nested directories. It is a collection of **independent skills** that collaborate via `requires`.

---

## Version History

| Version | Date | Changes |
|:---|:---|:---|
| v1.0 | 2026-05-04 | Initial release: 7 dimensions, 20 anti-patterns, 5 workflow patterns, 6-phase audit flow |
| v1.1 | 2026-05-04 | Added execution-audit distinction, Rationalizations Table, JSON intermediate outputs, detailed audit criteria reference, AGENTS.md support, severity ratings on anti-patterns, bilingual triggers |
| v1.2 | 2026-05-04 | Added Gotchas section, freedom calibration (F1-F3), Gotchas audit (G1-G5), three-layer architecture constraints, failure paths in Phase 1, verification step in Phase 6, allowed-tools declaration, self-audit fixes |
| v1.3 | 2026-05-05 | **CRITICAL FIX**: Restored strict "1-level deep" rule (S4); atoms/molecules/compounds must be **separate skills**, not nested subdirs. Added `--suite` mode for cross-skill relationship analysis. Added AP-21/22/23. validate_skill.py now checks: requires existence (nested metadata support), script duplication, architecture semantic alignment, layer direction validity, circular dependencies |
| v1.4 | 2026-05-05 | Added Flow Skill validation (Mermaid/D2 diagram, BEGIN/END nodes, choice markers). Added ASI-friendly description check (no implementation leaks in description). Added resilience mechanisms detection (timeout/retry/fallback/sensitive-op confirmation). Added credential isolation check (hardcoded secrets vs placeholders). Added AP-24/25/26/27. |
