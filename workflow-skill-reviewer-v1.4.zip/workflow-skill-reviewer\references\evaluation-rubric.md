# Evaluation Rubric

Priority-ordered rubric for scoring workflow-based skills. Fidelity always wins ties.

---

## Dimension 1: Trigger Accuracy (Weight: 20%)

**Core question**: Does the description activate at the right times and only then?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Third-person description with specific trigger keywords, explicit use cases, and named negative triggers. Immediately obvious when to use and when not to. |
| 70-89 | Contains trigger keywords and some use cases. Negative triggers are vague or missing. Might misfire on similar domains. |
| 50-69 | Generic description (e.g., "React skills"). Lacks specificity; agent must guess. |
| Below 50 | Missing, malformed, or misleading description. Guaranteed misfires. |

### Quality Gates
- **Must have**: `name` matches directory name; `description` ≤ 1024 chars.
- **Must have**: At least one explicit "Use when..." clause.
- **Should have**: At least one "Don't use for..." clause with named alternatives.

### Example: Good vs Bad Description

**Bad**:
```yaml
description: "React skills."
```

**Good**:
```yaml
description: |
  Creates and builds React components using Tailwind CSS. Use when the user 
  wants to update component styles or UI logic. Don't use it for Vue, Svelte, 
  or vanilla CSS projects.
```

---

## Dimension 2: Structural Fidelity (Weight: 20%)

**Core question**: Does it follow a recognizable pattern with numbered phases and clear criteria?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Recognizable pattern (Routing, Pipeline, Linear, Safety Gate, Task-Driven). All phases numbered with entry criteria, numbered actions, and exit criteria. Every branch ends at END. |
| 70-89 | Mostly structured but some phases lack entry/exit criteria, or pattern is mixed without explanation. |
| 50-69 | Has steps but unnumbered or in prose. Agent must infer ordering. |
| Below 50 | No structure; free-form prose instructions. Unreliable execution. |

### Quality Gates
- **Must have**: One recognizable pattern applied consistently.
- **Must have**: Every phase has a number and exit criteria.
- **Should have**: Entry criteria for every phase.
- **Should have**: BEGIN and END nodes clearly marked (Flow Skills).

---

## Dimension 3: Instruction Actionability (Weight: 20%)

**Core question**: Are steps deterministic enough to prevent agent hallucination?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Third-person imperative commands. Concrete templates or exact scripts for fragile steps. Input/output examples for key instructions. Agent never needs to guess. |
| 70-89 | Mostly actionable but some steps leave room for interpretation. Has examples but not for all critical paths. |
| 50-69 | Vague guidance ("analyze the code", "fix issues"). Agent must invent steps. |
| Below 50 | Instructions are abstract or assume domain knowledge the agent may not have. |

### Freedom Calibration Check

For each step, classify freedom level:
- **Low**: Exact commands, no variation (migrations, crypto, destructive actions)
- **Medium**: Pseudocode with parameters (preferred patterns with acceptable variation)
- **High**: Heuristics and judgment (code review, exploration, documentation)

A good skill mixes levels appropriately and labels them.

---

## Dimension 4: Context Efficiency (Weight: 15%)

**Core question**: Does it load only what's needed, when it's needed?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | SKILL.md < 300 lines. Details in `references/` and `scripts/` loaded JIT. No duplication between SKILL.md and references. |
| 70-89 | SKILL.md 300-500 lines. Some details offloaded but not consistently. Minor duplication. |
| 50-69 | SKILL.md 500-800 lines. Bulky content in main file. Agent loses focus. |
| Below 50 | SKILL.md > 800 lines or monolithic. Reference chains exist. |

### Quality Gates
- **Must have**: SKILL.md < 500 lines.
- **Must have**: No reference chains (A → B → C). All references one hop from SKILL.md.
- **Must have**: No `README.md`, `CHANGELOG.md`, or other human-facing docs.
- **Should have**: Large reference files (>100 lines) include a table of contents.

---

## Dimension 5: Drift Resistance (Weight: 10%)

**Core question**: Does it hold shape on edge-case inputs and failure states?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Explicit error handling section. Known failure modes documented. Guardrails for destructive actions. Edge cases addressed with specific fallbacks. |
| 70-89 | Some error handling but not systematic. Common failures covered, edge cases not. |
| 50-69 | Minimal error handling. Agent may proceed blindly on failure. |
| Below 50 | No error handling or guardrails. Assumes perfect execution. |

### Edge Case Prompts for Review

When auditing, ask the skill (or simulate):
1. "What if the primary script fails due to a missing dependency?"
2. "What if the user cancels mid-workflow?"
3. "What if the input file is empty or malformed?"
4. "What if a subagent returns no results?"

---

## Dimension 6: Tool Minimality (Weight: 10%)

**Core question**: Are tools precisely matched to the work with no over-privileging?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Exactly the tools needed, no more. Bash used only for operations without dedicated tools. Read-only skills have no Write/Bash. |
| 70-89 | Mostly correct but one or two unused tools declared, or missing a tool that would simplify steps. |
| 50-69 | Significant over-privileging (e.g., Bash declared but Glob/Grep would suffice). |
| Below 50 | Read-only skill declares Write/Bash, or critical tool missing. |

### Tool Rules
- Use `Glob` (not `find`), `Grep` (not `grep`), `Read` (not `cat`).
- Skills use `allowed-tools:`; agents use `tools:`.
- Read-only components: Read, Glob, Grep, TodoRead, TodoWrite only.

---

## Dimension 7: Scope Coherence (Weight: 5%)

**Core question**: Is it focused on one workflow without scope creep?

### Scoring Guide

| Score | Criteria |
|-------|----------|
| 90-100 | Single, clear purpose. Name reflects one job. No unrelated functionality bundled. |
| 70-89 | Primary purpose clear but includes tangential features that could be separate skills. |
| 50-69 | Attempts to cover multiple independent workflows without routing pattern. |
| Below 50 | "Do everything" skill. Unmaintainable and unreliable. |

### One Skill, One Job

Prefer:
- `standup-generator` + `code-reviewer` + `release-checklist`

Over:
- `dev-team-automation` (covers standup, review, release, and more)

---

## Tiebreaker Rules

1. **Fidelity-first**: Structural Fidelity beats Instruction Actionability if both are close.
2. **Trigger is gate**: If Trigger Accuracy < 50, overall score cannot exceed 60 regardless of other dimensions.
3. **Context is gate**: If Context Efficiency < 50, overall score cannot exceed 70.

## Overall Score Interpretation

| Range | Verdict | Action |
|-------|---------|--------|
| 90-100 | Excellent | Deploy. Minor polish optional. |
| 80-89 | Good | Deploy after addressing top 2-3 issues. |
| 70-79 | Acceptable | Address all Medium+ severity issues before deploy. |
| 60-69 | Needs Work | Major restructuring or content additions required. |
| Below 60 | Reject | Restart from pattern selection; fundamental flaws. |
