# AGENTS.md Audit Guide

AGENTS.md governs a directory and all subdirectories. Multiple AGENTS.md files can apply to a single file, with deeper directories taking precedence.

---

## When AGENTS.md Exists

If the target skill's project contains AGENTS.md, audit it alongside the skill using criteria A1-A6.

### A1: Context Rot Prevention

Keep AGENTS.md lean. Context window is shared with:
- System prompt
- Conversation history
- Skill metadata
- User request
- Tool outputs

**Thresholds**:
- 0-100 lines: Optimal
- 100-150 lines: Acceptable
- 150-300 lines: Risk zone — verify progressive disclosure
- > 300 lines: Context rot likely — must refactor

**Fix**: Move detailed rules to `.kimi/references/` or `references/` and link from AGENTS.md.

### A2: Step-by-Step Workflows

AGENTS.md should contain numbered workflows for common tasks:

```markdown
## Adding a New Feature

1. Read AGENTS.md for project conventions
2. Create feature branch
3. Implement with tests
4. Run lint and typecheck
5. Submit PR with description template
```

Not:
```markdown
## Adding a New Feature

Follow project conventions. Write tests. Submit PR.
```

### A3: Decision Tables

Replace ambiguous prose with tables:

```markdown
## Technology Choices

| Scenario | Use This | Not That | Why |
|----------|----------|----------|-----|
| New API endpoint | FastAPI + Pydantic | Flask | Type safety |
| Background jobs | Celery | Cron | Observability |
| Caching | Redis | In-memory | Persistence |
```

### A4: Concrete Code Snippets

Include 3-10 line realistic examples, not abstract descriptions:

```markdown
## Error Handling Pattern

```python
# Good: Specific exception with context
raise PaymentError(
    f"Card declined: {decline_code}",
    user_id=user.id,
    amount=order.total
)
```
```

### A5: Rule Cap

Maximum 10 core rules in AGENTS.md. Additional rules go to references:

```markdown
## Core Rules (max 10)

1. Use type hints everywhere
2. Prefer `pathlib` over `os.path`
3. ...

## Detailed Conventions
See `references/coding-standards.md` for:
- Naming conventions
- Docstring format
- Test patterns
```

### A6: Positive Guidance

Every prohibition must have a positive alternative:

| Bad | Good |
|-----|------|
| "Don't use `print()`" | "Don't use `print()` → use `structlog` instead" |
| "Never commit secrets" | "Never commit secrets → use `.env` + `python-dotenv`" |
| "No raw SQL" | "No raw SQL → use SQLAlchemy ORM or query builder" |

---

## AGENTS.md vs SKILL.md Relationship

| File | Scope | Audience | Lifetime |
|------|-------|----------|----------|
| AGENTS.md | Directory + subdirectories | All agents working in this project | Project-level |
| SKILL.md | Single skill | Agent that triggers this skill | Skill-level |

When both exist:
1. AGENTS.md provides project conventions
2. SKILL.md provides workflow-specific instructions
3. SKILL.md instructions override AGENTS.md for that skill's domain
